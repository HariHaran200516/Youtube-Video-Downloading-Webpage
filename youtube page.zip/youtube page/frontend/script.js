// Function to check if the given URL is a valid YouTube link
function isValidYouTubeUrl(url) {
    const regex = /^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+$/;
    return regex.test(url);
}

// Function to handle download button click
function downloadVideo() {
    const url = document.getElementById('videoUrl').value;
    const format = document.getElementById('format').value;
    const message = document.getElementById('message');

    if (!isValidYouTubeUrl(url)) {
        message.textContent = "❌ Please enter a valid YouTube URL!";
        return;
    }

    message.textContent = "✅ Download started...";

    // Redirect to backend API to process download
    window.location.href = `http://localhost:3000/download?url=${encodeURIComponent(url)}&format=${format}`;
}
