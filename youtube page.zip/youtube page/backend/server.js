const sanitizeHtml = require("sanitize-html");

app.get("/download", (req, res) => {
    let videoUrl = req.query.url;
    videoUrl = sanitizeHtml(videoUrl); // Clean user input

    if (!isValidYouTubeUrl(videoUrl)) {
        return res.status(400).json({ error: "Invalid YouTube URL!" });
    }
});
